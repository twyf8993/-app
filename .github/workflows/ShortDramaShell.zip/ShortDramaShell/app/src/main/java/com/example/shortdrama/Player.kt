package com.example.shortdrama

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PlayerScreen(nav: NavController, id: Int, startEp: Int) {
    val d = Mock.byId(id) ?: return
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    val pager = rememberPagerState(initialPage = startEp.coerceIn(0, d.episodes - 1)) { d.episodes }
    val scope = rememberCoroutineScope()
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var speedIdx by remember { mutableIntStateOf(0) }
    val speeds = listOf(1f, 1.25f, 1.5f, 2f, 0.75f)

    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    val n = pager.currentPage + 1
                    if (n < d.episodes) scope.launch { pager.animateScrollToPage(n) }
                }
            }
        }
        player.addListener(l)
        onDispose {
            Store.saveProgress(d.id, pager.currentPage, player.currentPosition)
            player.removeListener(l)
            player.release()
        }
    }

    // 切集：加载对应视频，并续播上次位置
    LaunchedEffect(pager.settledPage) {
        val ep = pager.settledPage
        val saved = Store.progress[d.id]
        player.setMediaItem(MediaItem.fromUri(Mock.videoUrl(d, ep)))
        player.prepare()
        val resume = if (saved != null && saved.ep == ep && saved.pos > 1000) saved.pos else 0L
        if (resume > 0) player.seekTo(resume)
        player.setPlaybackSpeed(speeds[speedIdx])
        player.playWhenReady = true
        Store.saveProgress(d.id, ep, resume)
    }

    // 刷新进度条，每 5 秒保存一次
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            delay(500)
            if (!dragging) pos = player.currentPosition
            dur = player.duration.coerceAtLeast(0L)
            tick++
            if (tick % 10 == 0) Store.saveProgress(d.id, pager.currentPage, player.currentPosition)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c -> PlayerView(c).apply { this.player = player; useController = false } },
            modifier = Modifier.fillMaxSize()
        )
        // 透明的翻页层：上下滑切集，点击暂停/播放
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) {
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null
                ) { if (player.isPlaying) player.pause() else player.play() }
            )
        }
        Row(Modifier.align(Alignment.TopStart).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回", tint = Color.White)
            }
            Text("${d.title}  第 ${pager.currentPage + 1} 集", color = Color.White)
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("上下滑动切换集数", color = Color.White.copy(alpha = 0.6f), modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    speedIdx = (speedIdx + 1) % speeds.size
                    player.setPlaybackSpeed(speeds[speedIdx])
                }) { Text("${speeds[speedIdx]}x", color = Color.White) }
            }
            Slider(
                value = pos.toFloat().coerceAtMost(maxOf(dur, 1L).toFloat()),
                onValueChange = { dragging = true; pos = it.toLong() },
                onValueChangeFinished = { player.seekTo(pos); dragging = false },
                valueRange = 0f..maxOf(dur, 1L).toFloat()
            )
        }
    }
}
