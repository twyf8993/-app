package com.example.shortdrama

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFE8445A),
                    background = Color(0xFF0D0D12),
                    surface = Color(0xFF1C1C24),
                    surfaceVariant = Color(0xFF2A2A34)
                )
            ) { App() }
        }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val tabs = listOf("home" to "首页", "filter" to "筛选", "rank" to "榜单", "search" to "搜索", "me" to "我的")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (route in tabs.map { it.first }) {
                NavigationBar {
                    tabs.forEach { (r, label) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = {
                                nav.navigate(r) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    when (r) {
                                        "home" -> Icons.Filled.Home
                                        "filter" -> Icons.Filled.Menu
                                        "rank" -> Icons.Filled.Star
                                        "search" -> Icons.Filled.Search
                                        else -> Icons.Filled.Person
                                    }, contentDescription = label
                                )
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { inner ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(inner)) {
            composable("home") { HomeScreen(nav) }
            composable("filter") { FilterScreen(nav) }
            composable("rank") { RankScreen(nav) }
            composable("search") { SearchScreen(nav) }
            composable("me") { MeScreen(nav) }
            composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.IntType })) {
                DetailScreen(nav, it.arguments!!.getInt("id"))
            }
            composable(
                "player/{id}/{ep}",
                arguments = listOf(
                    navArgument("id") { type = NavType.IntType },
                    navArgument("ep") { type = NavType.IntType })
            ) {
                PlayerScreen(nav, it.arguments!!.getInt("id"), it.arguments!!.getInt("ep"))
            }
        }
    }
}
