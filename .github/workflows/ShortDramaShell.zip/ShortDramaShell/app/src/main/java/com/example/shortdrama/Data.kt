package com.example.shortdrama

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf

data class Drama(
    val id: Int, val title: String, val type: String, val year: Int,
    val status: String, val tags: List<String>, val heat: Int,
    val episodes: Int, val desc: String
)

object Mock {
    private val names = listOf(
        "星河尽头的信", "雾城守夜人", "青岚渡", "第七号站台", "海边的灯塔店", "山河未眠",
        "纸飞机少年", "南巷旧事", "云端咖啡馆", "午夜电台", "归途如歌", "白塔之下",
        "夏日回声", "远山来信", "机械花园", "星尘邮差", "潮汐之约", "老街新声",
        "月光剧场", "风起长街", "琥珀时光", "荒原列车", "晨雾小镇", "银河便利店"
    )
    private val tagPool = listOf("悬疑", "都市", "奇幻", "治愈", "热血", "喜剧")
    private val types = listOf("短剧", "电影", "漫剧")
    // Blender 基金会的开源短片（CC 授权），仅用于测试播放
    private val videos = listOf(
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
    )

    val all: List<Drama> = names.mapIndexed { i, n ->
        val type = types[i % 3]
        Drama(
            id = i + 1, title = n, type = type, year = 2024 + i % 3,
            status = if (i % 4 == 0) "已完结" else "连载中",
            tags = listOf(tagPool[i % 6], tagPool[(i + 2) % 6]),
            heat = 120 + (i * 37) % 400,
            episodes = if (type == "电影") 1 else 8 + (i * 5) % 23,
            desc = "《$n》是一部用于测试的模拟作品，剧情为占位文字。" +
                "这里用来验证简介展开收起、标签展示和选集等界面效果。" +
                "替换成真实内容后，这段文字会由内容源提供。"
        )
    }

    fun byId(id: Int) = all.firstOrNull { it.id == id }
    fun videoUrl(d: Drama, ep: Int) = videos[(d.id + ep) % videos.size]
    val hotWords = listOf("悬疑", "都市", "奇幻", "治愈", "星河", "灯塔")
}

class Prog(val ep: Int, val pos: Long, val time: Long)

object Store {
    private lateinit var sp: SharedPreferences
    val progress = mutableStateMapOf<Int, Prog>()
    val favorites = mutableStateListOf<Int>()
    val history = mutableStateListOf<String>()

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.getSharedPreferences("store", Context.MODE_PRIVATE)
        sp.getString("progress", "")!!.split(";").filter { it.isNotBlank() }.forEach {
            val p = it.split(",")
            if (p.size == 4) progress[p[0].toInt()] = Prog(p[1].toInt(), p[2].toLong(), p[3].toLong())
        }
        favorites.addAll(sp.getString("fav", "")!!.split(",").mapNotNull { it.toIntOrNull() })
        history.addAll(sp.getString("hist", "")!!.split("\n").filter { it.isNotBlank() })
    }

    fun saveProgress(id: Int, ep: Int, pos: Long) {
        progress[id] = Prog(ep, pos, System.currentTimeMillis())
        sp.edit().putString("progress", progress.entries.joinToString(";") {
            "${it.key},${it.value.ep},${it.value.pos},${it.value.time}"
        }).apply()
    }

    fun clearProgress() {
        progress.clear(); sp.edit().remove("progress").apply()
    }

    fun toggleFav(id: Int) {
        if (id in favorites) favorites.remove(id) else favorites.add(id)
        sp.edit().putString("fav", favorites.joinToString(",")).apply()
    }

    fun addHistory(k: String) {
        if (k.isBlank()) return
        history.remove(k); history.add(0, k)
        while (history.size > 10) history.removeAt(history.size - 1)
        sp.edit().putString("hist", history.joinToString("\n")).apply()
    }

    fun clearHistory() {
        history.clear(); sp.edit().remove("hist").apply()
    }
}
