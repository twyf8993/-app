@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.example.shortdrama

import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

private val Gray = Color(0xFF9A9AA5)
private val Brand = Color(0xFFE8445A)

// ---------- 通用组件 ----------

@Composable
fun Poster(d: Drama, modifier: Modifier = Modifier, big: Boolean = false) {
    val h = (d.id * 47 % 360).toFloat()
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color.hsv(h, 0.5f, 0.55f), Color.hsv((h + 40) % 360, 0.6f, 0.25f)))),
        contentAlignment = Alignment.BottomStart
    ) {
        Text(
            d.title, color = Color.White, fontWeight = FontWeight.Bold,
            fontSize = if (big) 24.sp else 14.sp, modifier = Modifier.padding(8.dp)
        )
    }
}

@Composable
fun DramaCard(
    nav: NavController, d: Drama, sub: String,
    modifier: Modifier = Modifier, prog: Float? = null, badge: String? = null
) {
    Column(modifier.clickable { nav.navigate("detail/${d.id}") }) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.72f)) {
            Poster(d, Modifier.fillMaxSize())
            if (badge != null) {
                Text(
                    badge, color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.padding(6.dp).clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF2E9E5B)).padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
            if (prog != null) {
                LinearProgressIndicator(
                    progress = { prog },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(d.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
        Text(sub, color = Gray, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun Section(title: String, extra: String = "") {
    Row(verticalAlignment = Alignment.Bottom) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (extra.isNotEmpty()) {
            Spacer(Modifier.width(8.dp)); Text(extra, color = Gray, fontSize = 13.sp)
        }
    }
}

@Composable
fun ChipRow(options: List<String>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { FilterChip(selected = sel == it, onClick = { onSel(it) }, label = { Text(it) }) }
    }
}

@Composable
fun GridRows(nav: NavController, list: List<Drama>) {
    list.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { DramaCard(nav, it, "${it.heat} 万热度", Modifier.weight(1f)) }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

// ---------- 首页 ----------

@Composable
fun HomeScreen(nav: NavController) {
    var tab by remember { mutableStateOf("推荐") }
    val list = Mock.all.filter { tab == "推荐" || it.type == tab }
    val cont = Store.progress.entries.sortedByDescending { it.value.time }
        .mapNotNull { e -> Mock.byId(e.key)?.let { it to e.value } }
    val recent = list.takeLast(8).reversed()

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("影视盒子", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("海量内容 · 测试版", color = Gray)
                }
                IconButton(onClick = { nav.navigate("search") }) { Icon(Icons.Filled.Search, "搜索") }
            }
        }
        item { ChipRow(listOf("推荐", "电影", "漫剧"), tab) { tab = it } }
        if (cont.isNotEmpty()) {
            item { Section("继续观看") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(cont, key = { it.first.id }) { (d, p) ->
                        DramaCard(
                            nav, d, "看到第 ${p.ep + 1} 集", Modifier.width(120.dp),
                            prog = (p.ep + 1f) / d.episodes
                        )
                    }
                }
            }
        }
        item { Section("最近更新", "共 ${recent.size} 部") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(recent, key = { it.id }) {
                    DramaCard(nav, it, "${it.heat} 万热度", Modifier.width(120.dp), badge = "已上线")
                }
            }
        }
        item { Section("为你推荐", "每日更新") }
        item { Column { GridRows(nav, list) } }
    }
}

// ---------- 筛选 ----------

@Composable
fun FilterScreen(nav: NavController) {
    var type by remember { mutableStateOf("全部") }
    var year by remember { mutableStateOf("全部") }
    var status by remember { mutableStateOf("全部") }
    var shown by remember(type, year, status) { mutableIntStateOf(6) }
    val result = Mock.all.filter {
        (type == "全部" || it.type == type) &&
            (year == "全部" || it.year.toString() == year) &&
            (status == "全部" || it.status == status)
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("筛选", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item { ChipRow(listOf("全部", "短剧", "电影", "漫剧"), type) { type = it } }
        item { ChipRow(listOf("全部", "2024", "2025", "2026"), year) { year = it } }
        item { ChipRow(listOf("全部", "连载中", "已完结"), status) { status = it } }
        item { Text("共 ${result.size} 部", color = Gray) }
        item { Column { GridRows(nav, result.take(shown)) } }
        if (shown < result.size) {
            item {
                OutlinedButton(onClick = { shown += 6 }, modifier = Modifier.fillMaxWidth()) { Text("加载更多") }
            }
        }
    }
}

// ---------- 榜单 ----------

@Composable
fun RankScreen(nav: NavController) {
    var tab by remember { mutableIntStateOf(0) }
    val list = Mock.all.sortedByDescending { (it.heat * (tab + 3) + it.id * (tab * 17 + 5)) % 1000 }
    Column {
        TabRow(selectedTabIndex = tab) {
            listOf("日榜", "周榜", "总榜").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(list, key = { _, d -> d.id }) { i, d ->
                Row(
                    Modifier.fillMaxWidth().clickable { nav.navigate("detail/${d.id}") },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${i + 1}", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = if (i < 3) Color(0xFFFFB300) else Gray, modifier = Modifier.width(40.dp)
                    )
                    Poster(d, Modifier.size(56.dp, 76.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(d.title, fontWeight = FontWeight.Medium)
                        Text("${d.type} · ${d.heat} 万热度", color = Gray, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

// ---------- 搜索 ----------

@Composable
fun SearchScreen(nav: NavController) {
    var q by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    LaunchedEffect(q) { kotlinx.coroutines.delay(300); key = q.trim() }
    val result = if (key.isEmpty()) emptyList()
    else Mock.all.filter { d -> d.title.contains(key) || d.tags.any { it.contains(key) } }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), placeholder = { Text("搜索作品或标签") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { Store.addHistory(q.trim()) })
            )
        }
        if (key.isEmpty()) {
            if (Store.history.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Section("搜索历史")
                        TextButton(onClick = { Store.clearHistory() }) { Text("清空") }
                    }
                }
                item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Store.history.forEach { AssistChip(onClick = { q = it }, label = { Text(it) }) }
                } }
            }
            item { Section("热搜词") }
            item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mock.hotWords.forEach { AssistChip(onClick = { q = it }, label = { Text(it) }) }
            } }
        } else if (result.isEmpty()) {
            item { Text("没有找到相关内容", color = Gray) }
        } else {
            items(result, key = { it.id }) { d ->
                Row(
                    Modifier.fillMaxWidth().clickable { Store.addHistory(key); nav.navigate("detail/${d.id}") },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Poster(d, Modifier.size(56.dp, 76.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(d.title, fontWeight = FontWeight.Medium)
                        Text(d.tags.joinToString(" · "), color = Gray, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

// ---------- 我的 ----------

@Composable
fun MeScreen(nav: NavController) {
    val hist = Store.progress.entries.sortedByDescending { it.value.time }
        .mapNotNull { e -> Mock.byId(e.key)?.let { it to e.value } }
    val favs = Store.favorites.mapNotNull { Mock.byId(it) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("我的", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Section("观看历史")
                if (hist.isNotEmpty()) TextButton(onClick = { Store.clearProgress() }) { Text("清空") }
            }
        }
        if (hist.isEmpty()) item { Text("暂无观看记录", color = Gray) }
        items(hist, key = { "h" + it.first.id }) { (d, p) ->
            Text(
                "${d.title}  ·  看到第 ${p.ep + 1} 集",
                modifier = Modifier.fillMaxWidth().clickable { nav.navigate("player/${d.id}/${p.ep}") }.padding(vertical = 6.dp)
            )
        }
        item { Section("我的收藏") }
        if (favs.isEmpty()) item { Text("暂无收藏", color = Gray) }
        items(favs, key = { "f" + it.id }) { d ->
            Text(d.title, modifier = Modifier.fillMaxWidth().clickable { nav.navigate("detail/${d.id}") }.padding(vertical = 6.dp))
        }
        item { Text("本应用为测试版，内容均为模拟数据与开源测试视频。", color = Gray, fontSize = 12.sp) }
    }
}

// ---------- 详情 ----------

@Composable
fun DetailScreen(nav: NavController, id: Int) {
    val d = Mock.byId(id) ?: return
    val p = Store.progress[id]
    val fav = id in Store.favorites
    var expand by remember { mutableStateOf(false) }

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Box {
            Poster(d, Modifier.fillMaxWidth().height(300.dp), big = true)
            IconButton(onClick = { nav.popBackStack() }, modifier = Modifier.align(Alignment.TopStart)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回", tint = Color.White)
            }
            IconButton(onClick = { Store.toggleFav(id) }, modifier = Modifier.align(Alignment.TopEnd)) {
                Icon(Icons.Filled.Favorite, "收藏", tint = if (fav) Brand else Color.White.copy(alpha = 0.7f))
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(d.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${d.type} · ${d.year} · ${d.status} · ${d.heat} 万热度", color = Gray)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                d.tags.forEach { AssistChip(onClick = {}, label = { Text(it) }) }
            }
            Text(
                d.desc, maxLines = if (expand) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.clickable { expand = !expand }
            )
            Button(
                onClick = { nav.navigate("player/$id/${p?.ep ?: 0}") },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (p == null) "立即观看" else "继续观看 第 ${p.ep + 1} 集") }

            Text("选集（共 ${d.episodes} 集）", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in 0 until d.episodes) {
                    val watched = p != null && i < p.ep
                    val current = p != null && i == p.ep
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (watched) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
                            .border(if (current) 2.dp else 0.dp, if (current) Brand else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable { nav.navigate("player/$id/$i") },
                        contentAlignment = Alignment.Center
                    ) { Text("${i + 1}", color = if (watched) Gray else Color.White) }
                }
            }
        }
    }
}
