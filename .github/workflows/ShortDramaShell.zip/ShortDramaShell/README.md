# 影视盒子（第一阶段：影视壳）
模拟数据 + Blender 开源测试视频。
打包：上传到 GitHub → Actions → Build APK → Run workflow → 下载 app-debug-apk。
